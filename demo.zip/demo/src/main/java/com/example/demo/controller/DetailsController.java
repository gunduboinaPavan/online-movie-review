package com.example.demo.controller;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Details;
import com.example.demo.repository.DetailsRepository;

@CrossOrigin(origins="*")


@RestController
@RequestMapping("/api/v1/")
public class DetailsController {
	
	
	@Autowired
	private DetailsRepository detailsRepository;
	
	
	//get all movies
	@GetMapping("/details")
	public List<Details> getAllDetails(){
		
		return detailsRepository.findAll();
		
	}
	
	@PostMapping("/details")
	public Details createDetails(@RequestBody Details details) {
		return detailsRepository.save(details);
	}
	
	@GetMapping("/details/{id}")
	public ResponseEntity<Details>  getDetailsId(@PathVariable Long id) {
		Details details=detailsRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("movies id not found"));
		return 	ResponseEntity.ok(details);
		
	}
	
	@DeleteMapping("/details/{id}")
	public String deleteMovie(@PathVariable Long id){
		Details details=detailsRepository.findById(id).orElseThrow(()-> new ResourceNotFoundException("movies id not found"));
	
		detailsRepository.delete(details);
		
		return "1";
	}
	
	
	

}
