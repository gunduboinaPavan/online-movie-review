package com.example.demo.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="reviews")

public class Review{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	
	private long id;	
	@Column(name="name")
	private String name;
	@Column(name="review")
	private String review;
	@Column(name="movieid")
	private long movieid;
	@Column(name="status")
	private long status;
	
	
	public Review(){
			
			
			
		}
	
	
	

	public Review(String name, String review, long movieid, long status) {
		super();
		this.name = name;
		this.review = review;
		this.movieid = movieid;
		this.status = status;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public long getMovieid() {
		return movieid;
	}

	public void setMovieid(long movieid) {
		this.movieid = movieid;
	}
	
	
	public long getStatus() {
		return status;
	}

	public void setStatus(long status) {
		this.status = status;
	}
	
	
	
	
	


	



	

}


