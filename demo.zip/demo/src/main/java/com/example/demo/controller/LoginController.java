package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Details;
import com.example.demo.model.Login;
import com.example.demo.repository.LoginRepository;




@RestController
@CrossOrigin(origins="*")
@RequestMapping("/api/v1/")


public class LoginController{
	
	@Autowired
	private LoginRepository repo;
	
	@PostMapping("/register")
	public <T> T  createDetails(@RequestBody Login login) {
		String username= login.getUserId();
		if(repo.existsById(username)){
		 
			return (T)"-1";
		}
		else {
		return (T) repo.save(login);
		}
		
	}
	
	
	@PostMapping("/login")
	public String loginUser(@RequestBody Login loginData){
	
		String username= loginData.getUserId();
		long therole;
		String password;
	if(repo.existsById(username)){
	
	Login login=repo.findByUserId(username);
	
		if(login.getPassword().equals(loginData.getPassword())) {
			 therole=login.getRole();
			 
			 
			 System.out.println("The role:"+therole);
			if(therole==1) {
				return "11";
			}
			else {
				return "10";
			}
		}
			
		else
			return "0";
	}
	else {
		return "-1";
		
	}
	
	
		
	}
	
	//get all movies
		@GetMapping("/users")
		public List<Login> getAllDetails(){
			
			return repo.findAll();
			
		}
		
		
		@PutMapping("/users/{userId}")
		
		public ResponseEntity makeAsAdmin(@PathVariable String userId,@RequestBody Login loginbody) {
			
			Login login=repo.findById(userId).orElseThrow(()-> new ResourceNotFoundException("user id not found"));
			
			
			login.setRole(loginbody.getRole());
			login.setPassword(loginbody.getPassword());
			login.setUserId(loginbody.getUserId());
			
			Login updatelogin=repo.save(login);
			return ResponseEntity.ok(updatelogin);
			
		}
		
		
	
}


