package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="details")

public class Details {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	
	private long id;	
	@Column(name="mname")
	private String mname;
	@Column(name="mimg")
	private String mimg;
	@Column(name="myear")
	private String myear;
	
	
	
	public Details() {
		
		
	}
	
	
	
	
	
	
	
	
	public Details(String mname, String mimg, String myear) {
		super();
		this.mname = mname;
		this.mimg = mimg;
		this.myear = myear;
	}
	
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getMimg() {
		return mimg;
	}
	public void setMimg(String mimg) {
		this.mimg = mimg;
	}
	public String getMyear() {
		return myear;
	}
	public void setMyear(String myear) {
		this.myear = myear;
	}



	

}


