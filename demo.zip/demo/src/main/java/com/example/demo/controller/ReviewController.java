package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Login;
import com.example.demo.model.Review;
import com.example.demo.repository.ReviewRepository;





@RestController
@RequestMapping("/api/v1/")
@CrossOrigin(origins="*")

public class ReviewController{
	
	@Autowired
	private ReviewRepository repo;
	
	
	@GetMapping("/reviews")
	
	public List<Review> getAllReviews(){
		
		return repo.findAll();
		
	}
	
	@GetMapping("/reviews/{id}")
	public ResponseEntity<Review>  getDetailsId(@PathVariable Long movieid) {
		Review review=repo.findAllById(movieid);
		return 	ResponseEntity.ok(review);
		
	}
	
	@PostMapping("/reviews")
	public Review createReview(@RequestBody Review review) {
		return repo.save(review);
	}
	
	
	@PutMapping("/reviews/{id}")
	
	public ResponseEntity makeAsAdmin(@PathVariable long id,@RequestBody Review reviewBody) {
		
		Review review=repo.findById(id).orElseThrow(()-> new ResourceNotFoundException("user id not found"));
		
		
		review.setId(reviewBody.getId());
		review.setMovieid(reviewBody.getMovieid());
		review.setReview(reviewBody.getReview());
		review.setStatus(reviewBody.getStatus());
		
		Review reviewUpdate=repo.save(review);
		return ResponseEntity.ok(reviewUpdate);
		
	}
	
	
	
	
}


