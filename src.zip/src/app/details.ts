export class Details {
    id :any ;
    mname: any ;
    mimg: any;
    myear: any;

}
