import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Details } from '../details';
import { DetailsService } from '../details.service';
import { Router } from '@angular/router';
import { AnonymousSubject } from 'rxjs/internal/Subject';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit 
{

 
  
  logindetails:any={

  }
  details:Details=new Details();
  delete:any={
   
  };

  users:any[]=[];
  reviews:any[]=[];
  disReviews:any[]=[];
  dummyupdate:any;

  allmovies:Details[]=[];
  constructor(private detailsService: DetailsService, private router:Router) { }
  

 
  ngOnInit(): void {

    if(!localStorage.getItem("role")){
      this.router.navigate([''])

    }

    this.getDetails();
    this.getUsers();
    this.getReviews();
  

   
}

  saveDetails(){
    this.detailsService.createDetails(this.details).subscribe(
      data=>{
        alert("Data Uploaded");
      },
      error=>console.log(error)
      
    )
  }

   getDetails(){
    this.detailsService.getDetailsList().subscribe(
      data => {
        this.allmovies = data;
      
      });
  } 


  onSubmit(){

    this.saveDetails()

  }


  deleteMovie(x:any){
    
    this.detailsService.DeleteMovie(x).subscribe(
      data => {
   
        alert("deleted");
        this.getDetails()
        
        
      
      });


  }

  getUsers(){
    this.detailsService.getUsers().subscribe(
      data => {
        this.users = data;
        
      });
  }


setAdmin(id:any,login:any){
  
  this.dummyupdate=this.users[login];

  this.dummyupdate.role=1;
  
 this.detailsService.updateAdmin(id,this.users[login]).subscribe(
      data => {
        alert("Declared as admin");
      });

}
removeAdmin(id:any,login:any){
  
  this.dummyupdate=this.users[login];

  this.dummyupdate.role=0;
  
 this.detailsService.updateAdmin(id,this.users[login]).subscribe(
      data => {
        alert("Removed as admin");
      });

}






getReviews(){
  
  this.detailsService.getReviews().subscribe(
    data => {
      
      this.reviews = data.filter((x)=>  x.status!=1 );
      
   
      
      this.disReviews=data.filter((x)=> x.status==1);
      
    });
   
      


  

}


approveReview(id:any,index:any){
  
  this.dummyupdate=this.reviews[index];
  console.log(this.dummyupdate);

  this.dummyupdate.status=1;
  
 this.detailsService.onStatus(id,this.dummyupdate).subscribe(
      data => {
        alert("Review Approved");
        this.getReviews();
      });

}


disapproveReview(id:any,index:any){
  
  this.dummyupdate=this.disReviews[index];
  console.log(this.dummyupdate);

  this.dummyupdate.status=0;
  
 this.detailsService.onStatus(id,this.dummyupdate).subscribe(
      data => {
        alert("Review Disapproved");
        this.getReviews();
      });

}

}



