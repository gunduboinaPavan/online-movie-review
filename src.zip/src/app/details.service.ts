import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {  Observable } from 'rxjs';
import { Details } from './details';
@Injectable({
  providedIn: 'root'
})
export class DetailsService {

  private ip="http://44.211.176.251:8089";
  private baseURL=`${this.ip}/api/v1/details`;
  private registerURL=`${this.ip}/api/v1/register`;
  private loginURL=`${this.ip}/api/v1/login`;
  private reviewURL=`${this.ip}/api/v1/reviews`;
  private usersURL=`${this.ip}/api/v1/users`;
  constructor(private httpClient:HttpClient) { }


  getDetailsList(): Observable<Details[]>{

    return this.httpClient.get<Details[]>(`${this.baseURL}`);
  }



  createDetails(details:Details):Observable<any>{
    return this.httpClient.post(`${this.baseURL}`,details);
  }


  getDetailsId(id:any):Observable<Details[]>{

    return this.httpClient.get<Details[]>(`${this.baseURL}/${id}`);
  }

  createRegister(login:any):Observable<any>{
    return this.httpClient.post(`${this.registerURL}`,login);
  }

  checkLogin(login:any):Observable<any>{
    return this.httpClient.post(`${this.loginURL}`,login);
  }

  DeleteMovie(id:any):Observable<Details[]>{

    return this.httpClient.delete<Details[]>(`${this.baseURL}/${id}`);
  }

  getReview(id:any):Observable<any[]>{

    return this.httpClient.get<any[]>(`${this.reviewURL}/${id}`);
  }
  getReviews():Observable<any[]>{

    return this.httpClient.get<any[]>(`${this.reviewURL}`);
  }


  setReviews(review:any):Observable<any>{
    return this.httpClient.post(`${this.reviewURL}`,review);
  }

  
  getUsers(): Observable<Details[]>{

    return this.httpClient.get<Details[]>(`${this.usersURL}`);
  }

  updateAdmin(id:any,loginDetails:any):Observable<Details[]>{
   
    return this.httpClient.put<Details[]>(`${this.usersURL}/${id}`,loginDetails);
  }


  onStatus(id:any,reviewDetails:any):Observable<Details[]>{
   
    return this.httpClient.put<Details[]>(`${this.reviewURL}/${id}`,reviewDetails);
  }

}
