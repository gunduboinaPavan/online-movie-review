import { Component, OnInit } from '@angular/core';

import { DetailsService } from '../details.service';
import { ActivatedRoute, Route, Router } from '@angular/router';


@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {



  reviewsend:any={
    

  }
  username:any;
  details:any={
    
  };
  reviews:any[]=[];

  canReview:any;
  constructor(private detailsService: DetailsService, private activatedRoute : ActivatedRoute,private router:Router) { }
  
  movieid:any;
  ngOnInit(): void {
    window.scrollTo(0,0);
    if(localStorage.getItem("user"))
    {
      this.reviewsend.name=localStorage.getItem("user");
      
     
      this.canReview=true;
    }
    else{
      this.canReview=false;
    }
     

    this.movieid=this.activatedRoute.snapshot.paramMap.get('id');
    this.reviewsend.movieid=parseInt(this.movieid);

    
    this.getDetails();
    this.getReviews();
   
}



  private getDetails(){
    this.detailsService.getDetailsId(this.movieid).subscribe(
      data => {
        this.details = data;
        
        
      });


  } 

  getReviews(){
  
    this.detailsService.getReviews().subscribe(
      data => {
        
        this.reviews = data.filter((x)=>{ 
    
          if((x.movieid==this.movieid && x.status==1) ) {
            return true;
      
        }
      else{
        return false;
      }});
     
        
      
      });

    

  }

  reviewSubmit(){
  this.reviewsend.status=0;
    this.detailsService.setReviews(this.reviewsend).subscribe(
      data => {
        
        this.getReviews();
     alert("Review posted");
        
      
      });


  }





}
