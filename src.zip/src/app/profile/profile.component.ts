import { Component, OnInit } from '@angular/core';
import {  ActivatedRoute, Route, Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  constructor(private router:Router) { }

  user:any;
  subrole:any;
 
  routervar:any=this.router;

  ngOnInit(): void {
    this.user=localStorage.getItem('user')
    this.subrole=localStorage.getItem('role')
    this.router.events.subscribe(()=>{
      this.user=localStorage.getItem('user')
      this.subrole=localStorage.getItem('role')
    
    });
  }

  logout(){

    localStorage.removeItem("user")
    localStorage.removeItem("role")
    this.router.navigate(["/login"])

  }

}
