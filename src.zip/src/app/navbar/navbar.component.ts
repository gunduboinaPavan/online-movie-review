import { Component, OnChanges, OnInit } from '@angular/core';
import {  ActivatedRoute, Route, Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  
  constructor(private router:Router) { }
  user:any;
  role:any;
 
  routervar:any=this.router;
  ngOnInit(): void {
   
    this.user=localStorage.getItem('user')
    this.router.events.subscribe(()=>{
      this.user=localStorage.getItem('user')
      this.role=localStorage.getItem('role')
    });
  }

  logout(){

    localStorage.removeItem("user")
    localStorage.removeItem("role")
    this.router.navigate(["/login"])

  }



}
