

export class Register {

    name:any;
    pass:any;
    admin:any;
}
