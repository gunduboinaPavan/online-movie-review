import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DetailsService } from '../details.service';
import { Register } from '../register';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {


  registerDetails:any={

  }
 

  constructor(private detailsService: DetailsService, private router: Router ) { }

  ngOnInit(): void {




  }

  saveRegister(){
   
    console.log(this.registerDetails);
    this.detailsService.createRegister(this.registerDetails).subscribe(
      data=>{

        if(data=="-1"){
          alert("username already exists choose another");
        }
          else{
            alert("Regsitered successfull please login");
          }
        
        
        
        
      },
      error=>console.log(error)
      
    )
  }



   

  onRegister(){
    
    this.saveRegister();


  }

 

}
