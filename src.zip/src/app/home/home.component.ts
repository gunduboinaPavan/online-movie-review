import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DetailsService } from '../details.service';
import { Details } from '../details';
import { Router } from '@angular/router';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  details:Details[]=[];
  ls:any;
  constructor(private detailsService: DetailsService,private router: Router) { }
  

 
  ngOnInit(): void {
    // if(!localStorage.getItem("user")){
    //   this.router.navigate(['login'])

    // }
    
  
    this.getDetails();
}



  private getDetails(){
    this.detailsService.getDetailsList().subscribe(
      data => {
        this.details = data;
      
      });
  } 

 

 
}
