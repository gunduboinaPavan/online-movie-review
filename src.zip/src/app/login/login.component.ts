import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DetailsService } from '../details.service';
import { Register } from '../register';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {


  registerDetails:any={

  }
  loginDetails:any={
    
  }
  split_data:any;
  constructor(private detailsService: DetailsService, private router: Router ) { }

  ngOnInit(): void {
    if(localStorage.getItem("user")){
      this.router.navigate([''])

    }
  }


    checkLogin(){
     
   
    this.detailsService.checkLogin(this.loginDetails).subscribe(
      data=>{

       
       if(data=="11"){
      
       localStorage.setItem("user",this.loginDetails.userId);
       localStorage.setItem("role","1");
       this.router.navigate(['/admin'])

       
       }
       else if(data=="10"){
      
        localStorage.setItem("user",this.loginDetails.userId);
        this.router.navigate(['/'])
        if(localStorage.getItem('role')){
          localStorage.removeItem("role");
        }
        
        }
       else if(data=="-1"){
        alert("user not exist");
       }
       else if(data=="0"){
        alert("wrong user credentials");
       }
        
      },
      error=>console.log(error)
      
    )
  }



  onLogin(){

    this.checkLogin();

  }

}
